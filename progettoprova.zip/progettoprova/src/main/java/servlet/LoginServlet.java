package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;

import dao.AutoDao;
import dao.RichiestaDao;
import dao.UtenteDao;
import dto.Auto;
import dto.Utente;

@WebServlet("/loginlogout/*")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		resp.setContentType("application/json");// contenuto da cosa è formato

		HttpSession session = req.getSession();

		try {

			String requestURI = req.getRequestURI();
			System.out.println("RequestURI [" + requestURI + "]");
			
			RichiestaDao r=new RichiestaDao();
			r.insert(requestURI);

			String requestPath = requestURI.substring(requestURI.lastIndexOf('/') + 1);
			System.out.println("Request Path [" + requestPath + "]");

			if ("login".equalsIgnoreCase(requestPath)) {

				List<Utente> list = findAll(req);

				String user = req.getParameter("u");
				String pass = req.getParameter("p");

				for (int i = 0; i < list.size(); i++) {
					if (list.get(i).getPassword().equals(pass) && list.get(i).getUsername().equals(user)) {
						session.setAttribute("user_key", user);
						break;
					}
				}

			} else if ("logout".equalsIgnoreCase(requestPath)) {
				session.setAttribute("user_key", null);
			}

		} catch (Exception e) {

			e.printStackTrace();

			resp.getWriter().print("Si è verificato un errore inaspettato");
		}
	}

	private List<Utente> findAll(HttpServletRequest req) throws Exception {

		UtenteDao service = new UtenteDao();
		return service.findAll();
	}
}
