package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;

import dao.AutoDao;
import dao.RichiestaDao;
import dto.Auto;
import dto.Richiesta;

@WebServlet("/gestioneAuto/*")
public class AutoServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		resp.setContentType("application/json");
		try {

			String requestURI = req.getRequestURI();
			System.out.println("RequestURI [" + requestURI + "]");
			
			RichiestaDao r=new RichiestaDao();
			r.insert(requestURI);
			
			String requestPath = requestURI.substring(requestURI.lastIndexOf('/') + 1);
			System.out.println("Request Path [" + requestPath + "]");

			HttpSession session = req.getSession();
			// prima va la stringa fissa --> si evita un eccezione
			if (session.getAttribute("user_key") != null) {
				if ("inseriscitutto".equalsIgnoreCase(requestPath)) {

					AutoDao a = new AutoDao();
					a.insertAll();
				} else if ("cancella".equalsIgnoreCase(requestPath)) {

					String targa = req.getParameter("q");

					AutoDao auto = new AutoDao();
					auto.delete(targa);
				}

				else if ("ricercaAuto".equalsIgnoreCase(requestPath)) {

					List<Auto> list = findAll(req);

					ObjectMapper objmapper = new ObjectMapper();
					String jsonContent = objmapper.writeValueAsString(list);
					resp.getWriter().print(jsonContent);
				}
			}
			else
			{
				resp.getWriter().print("devi prma effettuare il login");
			}

		} catch (Exception e) {

			e.printStackTrace();

			resp.getWriter().print("Si è verificato un errore inaspettato");
		}
	}

	private List<Auto> findAll(HttpServletRequest req) throws Exception {

		AutoDao service = new AutoDao();
		return service.findAll();
	}
}
