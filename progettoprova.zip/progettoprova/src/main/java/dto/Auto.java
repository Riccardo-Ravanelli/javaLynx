package dto;

public class Auto {

	protected String targa;
	protected String modello;
	protected String marca;

	public Auto(String targa, String modello, String marca) {
		this.targa = targa;
		this.modello = modello;
		this.marca = marca;
	}

	public Auto() {
		// TODO Auto-generated constructor stub
	}

	public String getTarga() {
		return targa;
	}

	public void setTarga(String targa) {
		this.targa = targa;
	}

	public String getModello() {
		return modello;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

}
