package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dto.Auto;
import dto.Richiesta;

public class RichiestaDao {
	
	public Connection getConnection() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/autop", "root", "");
	}
	
	
	public void insert(String richiesta) throws Exception {

		StringBuilder sql = new StringBuilder();
		sql.append("INSERT INTO RICHIESTA(LINK) VALUES (?)");
		Connection connection = null;
		PreparedStatement pstm = null;

		try {
			connection = getConnection();
			pstm = connection.prepareStatement(sql.toString());
			pstm.setString(1, richiesta);
		
			pstm.executeUpdate();
		} catch (Exception e) {

			throw new Exception(e);

		} finally {

			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
		}
	}

}
