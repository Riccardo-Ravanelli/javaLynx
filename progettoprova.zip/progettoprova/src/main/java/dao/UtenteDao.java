package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dto.Auto;
import dto.Utente;

public class UtenteDao {
	
	public Connection getConnection() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/autop", "root", "");
	}
	
	public List<Utente> findAll() throws Exception {

		List<Utente> result = new ArrayList<Utente>();

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT ID, USERNAME, PASSWORD");
		sql.append(" FROM UTENTE");

		Connection connection = null;
		PreparedStatement pstm = null;// comunica ed esegue col db
		ResultSet rs = null; // scaricare dati dal db -- risultato di una query

		try {
			connection = getConnection();
			pstm = connection.prepareStatement(sql.toString());// permette di costruire sql precompilati nel db
			rs = pstm.executeQuery();

			while (rs.next()) {

				Utente utente = new Utente();

				utente.setId(rs.getInt("ID"));
				utente.setUsername(rs.getString("USERNAME"));
				utente.setPassword(rs.getString("PASSWORD"));

				result.add(utente);
			}
		} catch (Exception e) {

			throw new Exception(e);

		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
		}
		return result;
	}


}
