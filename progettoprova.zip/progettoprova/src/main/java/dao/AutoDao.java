package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dto.Auto;

public class AutoDao {

	public Connection getConnection() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/autop", "root", "");
	}

	public List<Auto> findAll() throws Exception {

		List<Auto> result = new ArrayList<Auto>();

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT TARGA, MODELLO, MARCA");
		sql.append(" FROM AUTO");

		Connection connection = null;
		PreparedStatement pstm = null;// comunica ed esegue col db
		ResultSet rs = null; // scaricare dati dal db -- risultato di una query

		try {
			connection = getConnection();
			pstm = connection.prepareStatement(sql.toString());// permette di costruire sql precompilati nel db
			rs = pstm.executeQuery();

			while (rs.next()) {

				Auto auto = new Auto();

				auto.setTarga(rs.getString("TARGA"));
				auto.setModello(rs.getString("MODELLO"));
				auto.setMarca(rs.getString("MARCA"));

				result.add(auto);
			}
		} catch (Exception e) {

			throw new Exception(e);

		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
		}
		return result;
	}

	public void insert(Auto auto) throws Exception {

		StringBuilder sql = new StringBuilder();
		sql.append("INSERT INTO AUTO(TARGA, MODELLO, MARCA) VALUES (?,?,?)");
		Connection connection = null;
		PreparedStatement pstm = null;

		try {
			connection = getConnection();
			pstm = connection.prepareStatement(sql.toString());
			pstm.setString(1, auto.getTarga());
			pstm.setString(2, auto.getModello());
			pstm.setString(3, auto.getMarca());

			pstm.executeUpdate();
		} catch (Exception e) {

			throw new Exception(e);

		} finally {

			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
		}
	}

	public void delete(String targa) throws Exception {

		StringBuilder sql = new StringBuilder();
		sql.append("DELETE FROM AUTO WHERE TARGA=?");
		Connection connection = null;
		PreparedStatement pstm = null;

		try {
			connection = getConnection();
			pstm = connection.prepareStatement(sql.toString());
			pstm.setString(1, targa);

			pstm.executeUpdate();
		} catch (Exception e) {

			throw new Exception(e);

		} finally {

			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
		}
	}
	
	public void insertAll() throws Exception {

		Auto a= new Auto();
		StringBuilder sql = new StringBuilder();
		sql.append("INSERT INTO AUTO(TARGA, MODELLO, MARCA) VALUES (?,?,?)");
		Connection connection = null;
		PreparedStatement pstm = null;

		try {
			connection = getConnection();
			pstm = connection.prepareStatement(sql.toString());
			
			for (int i=0;i<100;i++) {
			a.setTarga("ab12"+i+"c");
			a.setModello("pippo");
			a.setMarca("opele");
			pstm.setString(1, a.getTarga());
			pstm.setString(2, a.getModello());
			pstm.setString(3, a.getMarca());
			pstm.executeUpdate();
			}
		
		} catch (Exception e) {

			throw new Exception(e);

		} finally {

			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {
					// non faccio nulla
				}
			}
		}
	}

	

}
